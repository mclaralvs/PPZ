from twitter_scraper import get_tweets
for t in  get_tweets('#AmazonPrimeDay'):
    print (t)

