salário = 6500
aumento = salário * 0.05
novo = salário + aumento
print (novo)
