k = 1
fat = 1
while k <= 10:
  fat = fat * k
  k = k + 1
print (f'fat(10) = {fat}')

