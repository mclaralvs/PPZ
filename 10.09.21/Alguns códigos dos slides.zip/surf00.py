f = open('surf.txt')
for linha in f:
    print(linha.strip())
f.close()
##with open('surf.txt') as f:
##    print (f.read())
    
