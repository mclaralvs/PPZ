k = 1
fat = 1
n = int(input('n: '))
while k <= n:
  fat = fat * k
  k = k + 1
print (f'fat({n}) = {fat}')


