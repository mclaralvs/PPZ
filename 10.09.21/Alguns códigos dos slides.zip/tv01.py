class Televisão:
    def __init__(self):
        self.ligada = False
        self.canal = 2
