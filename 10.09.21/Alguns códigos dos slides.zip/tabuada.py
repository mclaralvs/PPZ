t = 1
while t <= 10:
  print (f'Tabuada do {t}')
  n = 1
  while n <= 10:
    print (f'{t} x {n} = {t*n}')
    n = n + 1
  t = t + 1
  print ()
