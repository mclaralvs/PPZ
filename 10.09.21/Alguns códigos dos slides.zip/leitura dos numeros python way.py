with open(r'c:/Users/fmasa/x.txt') as f:
  print (f.read())
