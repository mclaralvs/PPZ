palavra = input('Palavra: ')
palíndrome = palavra == palavra[::-1]
print (f'{palavra} é palíndrome?')
print (palíndrome)
