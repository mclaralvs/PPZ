José = 'entrou 6h'
def fatec():
  global José
  José = 'entrou 8h'
  print (José)
  
print (José)
fatec()
print (José)
