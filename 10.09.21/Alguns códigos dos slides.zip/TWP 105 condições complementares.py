idade = int(input("Digite a idade do seu carro: "))
if idade <= 3:
  print ("Seu carro é novo")
else:
  print ("Seu carro é velho")
